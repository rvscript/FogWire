/**
* FogWire
* Personal Encryption Software
* (c)5dz Productions 2009
*/

/*
 * Code for connecting to the database
 * Authenticating existing User
 * Adding new User
 */
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;

public class FogWireDB {

	private static Connection conn;
	private static Statement stmt;

//	//Main method
//	public static void main(String args[]) throws SQLException {
//		//Calls the method to load MySQL Driver
//		loadDriver();
//		//Calls the method to load Connect to the FogWire Database
//		connectToDatabase();
//		
//		/*We will pass down from the GUI whether or not this is a new user or
//		  an existing user
//		  If it is a new User (true) - then we add the user to the DB
//		  If it is an existing User (false) - then we Authenticate the user with the DB 
//		 */
//		boolean newUser = false;
//		if(newUser){
//		    AddUser();
//		}
//		else{
//			Authenticate(); 
//		}
//	}

	// This method loads MySQL driver (will reference "mysql-connector-java-5.1.8-bin.jar" file)
	public static void loadDriver(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			System.out.println("Driver problem!");
			//Below error traces used for testing only. Will be deleted for the final version.
			//e1.getMessage();
			//e1.printStackTrace();
		}
	}

	// This method will connect to the FogWire database
	public static void connectToDatabase(){	
		try {
			conn = DriverManager
			.getConnection("jdbc:mysql://76.163.252.20:3306/rvscrip_fogwire?"+"user=rvscrip_five&password=FiveDudes7");
			//Will let you know if you have successfully connected to the dtabase
			System.out.println("Connected to the database!");
			
		} catch (SQLException e1) {
			System.out.println("Connection to the database problem!");
			//Below error traces used for testing only. Will be deleted for the final version.
			//e1.getMessage();
			//e1.printStackTrace();
		}
	}

	//This method will interact with the database and Authenticate a user
	public static void Authenticate() throws SQLException {
		//Sets up a few parameters within the database
		conn.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		conn.setAutoCommit(false);
		
		//This creates the statement object
		stmt = conn.createStatement();

		try {	
			/*
			 * We will pass down User information from the GUI to be checked/Authenticated 
			 * with the database
			 * Below is a test sample
			 */
			String userFname = "Dmitry";
			String userLname = "Sharlot";
			String userMail = "dsharlot7@gmail.com";
			String pubKey = "1";

			//Fetches all of the result of the query to be analyzed
			ResultSet rs = stmt.executeQuery("select * from fogmail");

			//This will be the value passed back to the GUI saying either the user is found(authenticated - so OK to encrypt)
			//or not found (not authenticated - so not OK to encrypt)
			boolean found = false;

			while (rs.next()) {
				/*
				 * If all of the values checked match the database then - Authenticate user
				 */
				if ((rs.getString("F_NAME").equalsIgnoreCase(userFname))& 
					(rs.getString("L_NAME").equalsIgnoreCase(userLname))& 
					(rs.getString("E_MAIL").equalsIgnoreCase(userMail))& 
					(rs.getString("PUB_KEY").equalsIgnoreCase(pubKey)) ){
					System.out.println("Authenticated user: " + rs.getString("F_NAME")+ " " + rs.getString("L_NAME"));
					//Set found to true to let the program know that it is OK to proceed with encryption/decryption
					found = true;
				}
			}
			
			//If a value does not match there is an authentication error
			if(found == false)
				System.out.println("Authentication failed - please check user information and try again");

		} catch (SQLException e) {
			// If a problem occurs at any point of the authentication process the database is rolled back
			System.out.println("Authentication failed - please check user information and try again");
			
			//Below error traces used for testing only. Will be deleted for the final version.
			//System.out.println("SQL exception caught in your code!!! - rolled back");
			//e.printStackTrace();
			
			//Will roll back database and close connection to the database if there is an Authentication error
			conn.rollback();
			stmt.close();
			conn.close();
			System.out.println("Database connection closed!");
			return;
		}

		//If Authentication is successful we close out of the database
		conn.commit();
		stmt.close();
		conn.close();
		System.out.println("Database connection closed!");

	}
	
	
	//This method will interact with the database and Add a user
	public static void AddUser() throws SQLException {
		//Sets up a few parameters within the database
		conn.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		conn.setAutoCommit(false);

		//This creates the statement object
		stmt = conn.createStatement();
		
		/*
		 * We will pass down User information from the GUI to be checked/Authenticated 
		 * with the database
		 * Below is a test sample
		 */
		
		//FogWireLogin login = new FogWireLogin();
		
		String userFname = FogWireLogin.getFirstName().getText();
		String userLname = FogWireLogin.getLastName().getText();
		String userMail = FogWireLogin.getEmailAddress().getText();
		String pubKey = "1234588999";
		
		try {
			
			//This will add the necessary values into the database - creating a new user
			stmt.executeUpdate("insert into fogmail values ('"+userFname+"','"+userLname+"','"+userMail+"','"+pubKey+"')");

			//Fetches all of the result of the query to be analyzed
			ResultSet rs = stmt.executeQuery("select * from fogmail");

			//This will be the value passed back to the GUI saying either the user is added to the database
			//or there was a problem and the insert failed
			boolean found = false;
     
			
			while (rs.next()) {
				/*
				 * If all of the values checked match the database then - Add user
				 */
				if ((rs.getString("F_NAME").equalsIgnoreCase(userFname))& 
					(rs.getString("L_NAME").equalsIgnoreCase(userLname))& 
					(rs.getString("E_MAIL").equalsIgnoreCase(userMail))& 
					(rs.getString("PUB_KEY").equalsIgnoreCase(pubKey)) ){
					System.out.println("Registered user: " + rs.getString("F_NAME") + " " + rs.getString("L_NAME"));
					found = true;
				}
			}
			//If their is a problem with adding the user - we ask the user to register again
			if(found == false)
				System.out.println("User not registered please try again");

		} catch (SQLException e) {
			// If a problem occurs at any point in the addition process the database is rolled back
			System.out.println("The user: " + userFname + " " + userLname + " is already registered");
			
			//Below error traces used for testing only. Will be deleted for the final version.
			//System.out.println("SQL exception caught in your code!!! - rolled back");
			//e.printStackTrace();
			
			//Will roll back database and close connection to the database if there is an addition error
			conn.rollback();
			stmt.close();
			conn.close();
			System.out.println("Database connection closed!");
			return;
		}

		//If Addition is successful we close out of the database
		conn.commit();
		stmt.close();
		conn.close();
		System.out.println("Database connection closed!");

	}
}
