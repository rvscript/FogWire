
import java.io.*;
public class runRWfile {

	/**
	 * test running a file
	 * reading a file
	 * Use the comment bars to pic a file to encrypt test and or copy
	 */
	public static void main(String[] args) throws IOException{
		//int key = 41477;
		// create new of RWfull
		
		//String fileName="wwe.jpg"           , copyTo = "E_binary.jpg";	
		//String fileName="italian.jpg"       , copyTo= "E_binary.jpg";
		//String fileName="Samerica.jpg"      , copyTo="E_binary.jpg";
		//String fileName="playground.jpg"    , copyTo="E_binary.jpg";
		//String fileName="latinDataBase.jpg" , copyTo="E_binary.jpg";
				
		//String fileName="test.txt"          ,copyTo="E_binary.txt";
		//String fileName="Fogwire_Requirements.docx",copyTo="E_binary.docx";
		//String fileName="inspiration.pdf"   ,copyTo="E_binary.pdf";
			
		//String fileName="E_binary.jpg"      , copyTo = "binary.jpg";
		//String fileName="E_binary.pdf"   ,copyTo="binary.pdf";	
		//String fileName = "E_binary.txt"      ,copyTo="binary.txt";
		//String fileName = "E_binary.docx"     ,copyTo = "binary.docx";
		
		//RWfull rw = new RWfull(fileName);  
		//ReadWriteBinFile rwf = new ReadWriteBinFile(fileName, copyTo);
		
		//ReadToEncrypt re =        new ReadToEncrypt(fileName, copyTo);
		//ReadToDecrypt rd =        new ReadToDecrypt(fileName, copyTo);
		
		//DesKeyGen dkg = new DesKeyGen();
		//dkg.genDesKey(key);
		
		//RSAkeygenerator rkg = new RSAkeygenerator();
		
	}

}
