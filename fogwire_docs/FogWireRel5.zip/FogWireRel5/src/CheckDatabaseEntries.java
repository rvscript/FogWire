
/**
* FogWire
* Personal Encryption Software
* (c)5dz Productions 2009
*/

//Code to check who is in the database
import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckDatabaseEntries {


	public static void main(String args[]) throws SQLException, IOException, ClassNotFoundException {

		// Load the MySQL driver
		Class.forName("com.mysql.jdbc.Driver");

		// Connect to the database
		Connection conn = DriverManager
		.getConnection("jdbc:mysql://76.163.252.20:3306/rvscrip_fogwire?"
				+ "user=rvscrip_five&password=FiveDudes7");

		Statement stmt = conn.createStatement();

		ResultSet rs = stmt.executeQuery("select * from  fogmail");

		//Just brings back the first name and email
		while (rs.next()) {
			System.out.println("NAME: " + rs.getString("f_name")+ "		EMAIL: " +rs.getString("e_mail"));
		}
	}
}