/**
* FogWire
* Personal Encryption Software
* (c)5dz Productions
*/

/*
 * Code to send email through the FogWire gmail account
 */
import java.io.File;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeMessage.RecipientType;

public class FogMail {
	
	private static final String SMTP_HOST_NAME = "smtp.gmail.com"; 
	private static final String SMTP_AUTH_USER = "fogwire@gmail.com";
	private static final String SMTP_AUTH_PWD  = "FiveDudes7";// - this line will be deleted
	//This password will be encrypted so it will look like gibberish.
	//private static final String SMTP_AUTH_PWD  = "#$%^&*()))(*&";
	
	//We will have a Decryption class that will take SMTP_AUTH_PWD Decrypt it
	//and bring it back here as - SMTP_AUTH_PWD_tmp - we will use this as the Authenticator 
	//to gmail and then null it out right after..
	
	//public static void main(String[] args) {      
	public void sendMail(){
		try {   
			//This sets the right properties for gmail message sending
			Properties props = System.getProperties();            
			props.put("mail.smtp.starttls.enable", "true");        
			props.put("mail.smtp.host", SMTP_HOST_NAME);      
			props.put("mail.smtp.auth", "true");           
			props.put("mail.smtp.port", "587"); // gmail smtp port     
			
			//Authenticates correct user and password with gmail
			Authenticator auth = new Authenticator() {
				@Override                
				protected PasswordAuthentication getPasswordAuthentication() {                    
					return new PasswordAuthentication(SMTP_AUTH_USER, SMTP_AUTH_PWD); 
				}           
			};    
			
			//Creates a new session by calling the Properties and the Authentication
			Session session = Session.getDefaultInstance(props, auth); 
			
			
			MimeMessage msg = new MimeMessage(session);   
			//From: Address
			msg.setFrom(new InternetAddress("SMTP_AUTH_USER"));  
			//Subject line
			msg.setSubject("You have a new message from FogWire!");  
			//To: Address
			//msg.setRecipient(RecipientType.TO, new InternetAddress("the_5dz@googlegroups.com")); 
			
			//FogWire1121 send = new FogWire1121();
			msg.setRecipient(RecipientType.TO, new InternetAddress(FogWire1121.toField.getText())); 
			
			//Can put your own email in the line below and comment out the top for testing
			//msg.setRecipient(RecipientType.TO, new InternetAddress("email address"));
			
			
			//This is the Text inside the body of the email          
			//MimeBodyPart body = new MimeBodyPart();  
			//body.setText("\n Body of the email ");
			
			//Attaches a file 
			MimeBodyPart attachMent = new MimeBodyPart();     
			
			//Points to where we grab the file from - specifies the path
			FileDataSource dataSource = new FileDataSource(new File("C:\\FogWire2\\Locked_Docs\\locked.txt"));
			
			attachMent.setDataHandler(new DataHandler(dataSource));        
			
			//Sets the name for the file that will be attached
			attachMent.setFileName("locked.txt");  
			
			attachMent.setDisposition(MimeBodyPart.ATTACHMENT);        
			Multipart multipart = new MimeMultipart();          
			//multipart.addBodyPart(body);         
			multipart.addBodyPart(attachMent);           
			msg.setContent(multipart);           
			Transport.send(msg);  
			
			//Lets you know if the file has been sent successfully
			System.out.println("Sucessfully Sent Mail");
			
		} catch (AddressException ex) {            
			Logger.getLogger(FogMail.class.getName()).log(Level.SEVERE, null, ex);  
			System.out.println("Error - mail not sent");
		} catch (MessagingException ex) {            
			Logger.getLogger(FogMail.class.getName()).log(Level.SEVERE, null, ex);  
			System.out.println("Error - mail not sent");
		}    
	}
}


