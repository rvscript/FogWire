import java.io.File;


public class FogWireDriver {

	/**
	 * @param args
	 */


	public static void main(String[] args) {

		//try to get this file
		File myFile = new File("C:\\FogWire2\\foggy.txt");
		try{
			if(myFile.exists()){
				System.out.println("found it");
				//start Main FogWire
				FogWire1121.run();			
			}
			else{
				System.out.println("not here");
				//start Login registration
				FogWireLogin.run();
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
