/**
* FogWire
* Personal Encryption Software
* (c)5dz Productions 2009
* @version 1.0
* @authors Ricardo Viera, Dmitry Sharlot, Joseph Everett, Anthony Sinatra
*/

public class RunRSAKeyGenerator{

	/**
	 * test main for RSA KeyGenerator
	 */
	
	public static void main(String[] args) {
		// yeah
    //RSAkeygenerator rsa = new RSAkeygenerator();
		
		//Enter SqMult( e, N, d, a) ;
		//'a' is the number to Encrypt and Decrypt 
    SqMult sm = new SqMult(859, 22045, 9011,2987);
	}
}
